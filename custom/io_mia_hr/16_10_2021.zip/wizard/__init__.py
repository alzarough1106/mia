# -*- coding: utf-8 -*-
from . import loza_employee_transfer