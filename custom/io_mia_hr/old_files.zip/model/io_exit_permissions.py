# -*- coding: utf-8 -*-
############################################################################
#
# Abr Afrikia LTD CONFIDENTIAL
# __________________
#
#  [2020] - [2021] Abr Afrikia Limited - Tripoli Libya
#  All Rights Reserved.
#
# NOTICE:  All information contained herein is, and remains
# the property of Abr Afrikia Limited and its suppliers,
# if any.  The intellectual and technical concepts contained
# herein are proprietary to Abr Afrikia Limited
# and its suppliers and may be covered by International Laws and Patents,
# patents in process, and are protected by trade secret or copyright law.
# Dissemination of this information or reproduction of this material
# is strictly forbidden unless prior written permission is obtained
# from Abr Afrikia Limited
#
#############################################################################
from odoo import api, fields, models, _
from datetime import date
from datetime import timedelta
from odoo.exceptions import Warning, UserError
import datetime


class io_exit_permissions(models.Model):
    _name = "io.exit.permissions"
    _order = 'exit_dt desc'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'The exit permission of an employee'
    _rec_name = "exit_id"

    '''
    The exit permission for an employee
    '''
    exit_id = fields.Char(string='أذن الخروج', copy=False, readonly=True)
    exit_dt = fields.Date(string="Date", default=date.today())
    check_out_time = fields.Datetime(string="وقت الخروج")
    check_in_time = fields.Datetime(string="وقت العودة")
    employee_id = fields.Many2one('hr.employee', string='Employee',
                                  index=True, auto_join=True, ondelete="cascade",
                                  help="The Employee who has exit permissions")
    state = fields.Selection([
        ('draft', 'مسودة'),
        ('done', 'Done'),
    ], string='Status', readonly=True, copy=False, default='draft')

    @api.model
    def create(self, vals):
        vals['exit_id'] = self.env['ir.sequence'].next_by_code('io.exit.permissions') or 'EXT'
        result = super(io_exit_permissions, self).create(vals)
        msg_body = 'تم إنشاء إذن الخروج'
        for msg in self:
            msg.message_post(body=msg_body)
        return result

    def action_accept_exit_permission(self):
        # mark the entry as exited and exist
        outer_dt = self.exit_dt + timedelta(days=1)
        attendance_record = self.env['hr.attendance'].search([
            ('check_in', '>=', self.exit_dt),
            ('employee_id', '=', self.employee_id.id),
            ('check_in', '<=', outer_dt),
        ])

        if not attendance_record:
            raise UserError('There is no record checkin for this employee')
        # otherwise just update the record
        attendance_record.status = 'late'
        attendance_record.check_out = outer_dt
        # mytime = attendance_record.check_in.time()
        #
        # if mytime.hour <= 9:
        #         attendance_record.status = 'present'
        # elif mytime.minute > 0:
